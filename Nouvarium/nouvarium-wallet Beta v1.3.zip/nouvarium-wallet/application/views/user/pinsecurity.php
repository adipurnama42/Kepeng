<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center">
            <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="" class="logo-nouva1 mb-5">
            <h1>Confirm your PIN</h1>
        </div>
        <div class="section mt-2 mb-5 p-3">
            <form action="<?= base_url('homepage/pinSecurity') ?>" method="POST" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <input type="text" name="pin" class="form-control verification-input border-0" id="smscode" placeholder="••••••" maxlength="6" style="width: 250px;">
                    <?= form_error('pin', '<small class="text-danger text-center d-block">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Confirm</button>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->