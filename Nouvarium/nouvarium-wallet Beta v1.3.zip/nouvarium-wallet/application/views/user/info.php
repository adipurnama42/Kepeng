<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">

        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-8">
                    <span class="title-name text-nouva1"><?= $data_user['name']; ?></span>
                    <span class="code-id"><?= $data_user['email']; ?></span>
                </div>
                <div class="col-4">
                    <div class="profile-img">
                        <?php if ($data_user["photo_profile"] != NULL) { ?>
                            <img src="<?= base_url('assets/img/users/' . $data_user['photo_profile']) ?>" alt="image" class="imaged w76" style="height: 100%;" />
                        <?php } else { ?>
                            <img src="<?= base_url('assets'); ?>/img/users/profile.png" alt="image" class="imaged w76" style="height: 100%;">
                        <?php } ?>
                    </div>
                </div>
                <div class="col-12">
                    <div class="balance-kpg text-nouva1">
                        <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG">
                        <span><?= number_format($data_dompet_user['saldo'], 2, '.', ','); ?> KPG</span><br>
                        <span class="tittle-today">$0 Today</span>
                    </div>
                </div>

                <div class="col-12 wallet-card bg-transparent border-0 shadow-none m-0 p-0">
                    <div class="wallet-footer border-0">
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#receiveActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/receive-icon.svg" alt="Receive">
                                </div>
                                <strong>Receive</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#sendActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/send-icon.svg" alt="Receive">
                                </div>
                                <strong>Send</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#buyActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/buy-icon.svg" alt="Receive">
                                </div>
                                <strong>Buy</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#scanActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/Scan.svg" alt="Receive">
                                </div>
                                <strong>Scan</strong>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4 pb-5">
            <h2 class="title text-nouva1 mb-2">Kepeng News</h2>
            <div class="mt-3">
                <div class="carousel-single owl-carousel owl-theme shadowfix">
                    <!-- item -->
                    <div class="item">
                        <a href="#">
                            <div class="blog-card">
                                <img src="assets/img/1.jpeg" alt="image" class="imaged w-100">
                                <div class="text">
                                    <h4 class="title">Blog 1 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                    <h6 class="mt-1">September 5, 2021</h6>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- * item -->
                    <!-- item -->
                    <div class="item">
                        <a href="#">
                            <div class="blog-card">
                                <img src="assets/img/2.jpeg" alt="image" class="imaged w-100">
                                <div class="text">
                                    <h4 class="title">Blog 2 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                    <h6 class="mt-1">September 5, 2021</h6>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- * item -->
                    <!-- item -->
                    <div class="item">
                        <a href="#">
                            <div class="blog-card">
                                <img src="assets/img/3.jpeg" alt="image" class="imaged w-100">
                                <div class="text">
                                    <h4 class="title">Blog 3 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                    <h6 class="mt-1">September 5, 2021</h6>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- * item -->
                </div>
            </div>


            <div class="mt-5">
                <h2 class="title text-nouva1 mb-2">Kepeng Hots</h2>
                <div class="shadowfix">
                    <a href="#" class="">
                        <div class="blog-card mb-2">
                            <img src="assets/img/1.jpeg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">Blog 1 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                <h6 class="mt-1">September 5, 2021</h6>
                            </div>
                        </div>
                    </a>
                    <!-- * item -->
                    <!-- item -->
                    <a href="#">
                        <div class="blog-card">
                            <img src="assets/img/2.jpeg" alt="image" class="imaged w-100">
                            <div class="text">
                                <h4 class="title">Blog 2 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                <h6 class="mt-1">September 5, 2021</h6>
                            </div>
                        </div>
                    </a>
                    <!-- * item -->
                </div>
            </div>
            <div class="mt-5">
                <div class="col-12 mt-3 mb-3 d-flex justify-content-center" role="tablist">
                    <a href="" class="transactions-fitur d-inline-block mr-0">
                        View all
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- * Transactions -->

    </div>
    <!-- * App Capsule -->