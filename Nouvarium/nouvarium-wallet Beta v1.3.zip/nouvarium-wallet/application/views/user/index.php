<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">
        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-8">
                    <span class="title-name text-nouva1"><?= $data_user['name']; ?></span>
                    <span class="code-id"><?= $data_user['email']; ?></span>
                </div>
                <div class="col-4">
                    <div class="profile-img">
                        <?php if ($data_user["photo_profile"] != NULL) { ?>
                            <img src="<?= base_url('assets/img/users/' . $data_user['photo_profile']) ?>" alt="image" class="imaged w76" style="height: 100%;" />
                        <?php } else { ?>
                            <img src="<?= base_url('assets'); ?>/img/users/profile.png" alt="image" class="imaged w76" style="height: 100%;">
                        <?php } ?>
                    </div>
                </div>
                <div class="col-12">
                    <div class="balance-kpg text-nouva1">
                        <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG">
                        <span><?= number_format($data_dompet_user['saldo'], 2, '.', ','); ?> KPG</span><br>
                        <span class="tittle-today">$0 Today</span>
                    </div>
                </div>

                <div class="col-12 wallet-card bg-transparent border-0 shadow-none m-0 p-0">
                    <div class="wallet-footer border-0">
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#receiveActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/receive-icon.svg" alt="Receive">
                                </div>
                                <strong>Receive</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#sendActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/send-icon.svg" alt="Receive">
                                </div>
                                <strong>Send</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#buyActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/buy-icon.svg" alt="Receive">
                                </div>
                                <strong>Buy</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#scanActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/Scan.svg" alt="Receive">
                                </div>
                                <strong>Scan</strong>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4 pb-5">
            <h2 class="title text-nouva1 mb-2">Transactions</h2>
            <div class="row">
                <div class="nav col-12 d-flex justify-content-start" role="tablist">
                    <a class="transactions-fitur" id="all-tab" data-toggle="tab" href="#all" role="tab" aria-controls="all" aria-selected="true">All</a>
                    <a class="transactions-fitur text-success" id="in-tab" data-toggle="tab" href="#in" role="tab" aria-controls="in" aria-selected="false">In</a>
                    <a class="transactions-fitur text-danger" id="out-tab" data-toggle="tab" href="#out" role="tab" aria-controls="out" aria-selected="false">Out</a>
                </div>
            </div>

            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                    <div class="mt-5">
                        <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Today</h4>
                        <div class="transactions">
                            <?php
                            if ($today) {
                                foreach ($today as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['sender_name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $transakasi['recipient_name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1" data-toggle="modal" data-target="#detailActionSheet<?= $transakasi['id_transaksi']; ?>">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>

                    <div class="mt-5">
                        <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Yesterday</h4>
                        <div class="transactions">
                            <?php
                            if ($yesterday) {
                                foreach ($yesterday as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['sender_name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $transakasi['recipient_name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1" data-toggle="modal" data-target="#detailActionSheet<?= $transakasi['id_transaksi']; ?>">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>

                </div>

                <div class="tab-pane fade" id="in" role="tabpanel" aria-labelledby="in-tab">
                    <div class="mt-5">
                        <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Today</h4>
                        <div class="transactions">
                            <?php
                            if ($today_receive) {
                                foreach ($today_receive as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['sender_name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $transakasi['recipient_name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1" data-toggle="modal" data-target="#detailActionSheet<?= $transakasi['id_transaksi']; ?>">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>

                    <div class="mt-5">
                        <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Yesterday</h4>
                        <div class="transactions">
                            <?php
                            if ($yesterday_receive) {
                                foreach ($yesterday_receive as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['sender_name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $transakasi['recipient_name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1" data-toggle="modal" data-target="#detailActionSheet<?= $transakasi['id_transaksi']; ?>">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="out" role="tabpanel" aria-labelledby="out-tab">
                    <div class="mt-5">
                        <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Today</h4>
                        <div class="transactions">
                            <?php
                            if ($today_sender) {
                                foreach ($today_sender as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['sender_name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $transakasi['recipient_name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1" data-toggle="modal" data-target="#detailActionSheet<?= $transakasi['id_transaksi']; ?>">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>

                    <div class="mt-5">
                        <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Yesterday</h4>
                        <div class="transactions">
                            <?php
                            if ($yesterday_sender) {
                                foreach ($yesterday_sender as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['sender_name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $transakasi['recipient_name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1" data-toggle="modal" data-target="#detailActionSheet<?= $transakasi['id_transaksi']; ?>">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-5">
                <div class="col-12 mt-3 mb-3 d-flex justify-content-center" role="tablist">
                    <a href="" class="transactions-fitur d-inline-block mr-0">
                        View all
                    </a>
                </div>
            </div>

            <div class="mt-5">
                <h2 class="title text-nouva1 mb-2">Info</h2>
                <div class="mt-3">
                    <div class="carousel-single owl-carousel owl-theme shadowfix">
                        <!-- item -->
                        <div class="item">
                            <a href="#">
                                <div class="blog-card">
                                    <img src="<?= base_url(); ?>assets/img/1.jpeg" alt="image" class="imaged w-100">
                                    <div class="text">
                                        <h4 class="title">Blog 1 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                        <h6 class="mt-1">September 5, 2021</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <!-- * item -->
                        <!-- item -->
                        <div class="item">
                            <a href="#">
                                <div class="blog-card">
                                    <img src="<?= base_url(); ?>assets/img/2.jpeg" alt="image" class="imaged w-100">
                                    <div class="text">
                                        <h4 class="title">Blog 2 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                        <h6 class="mt-1">September 5, 2021</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <!-- * item -->
                        <!-- item -->
                        <div class="item">
                            <a href="#">
                                <div class="blog-card">
                                    <img src="<?= base_url(); ?>assets/img/3.jpeg" alt="image" class="imaged w-100">
                                    <div class="text">
                                        <h4 class="title">Blog 3 ipsum dolor, sit amet consectetur adipisicing elit. Voluptate, accusamus.</h4>
                                        <h6 class="mt-1">September 5, 2021</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <!-- * item -->
                    </div>
                </div>


                <div class="mt-5">
                    <div class="col-12 mt-3 mb-3 d-flex justify-content-center" role="tablist">
                        <a href="" class="transactions-fitur d-inline-block mr-0">
                            View all
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- * Transactions -->

    </div>
    <!-- * App Capsule -->