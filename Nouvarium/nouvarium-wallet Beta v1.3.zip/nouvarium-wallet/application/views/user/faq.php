<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">

        <!-- Wallet Card -->
        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-12">
                    <div class="profile-img edit">
                        <label for="upload_image">
                            <?php if ($data_user["photo_profile"] != NULL) { ?>
                                <img src="<?= base_url('assets/img/users/' . $data_user['photo_profile']) ?>" id="uploaded_image" alt="image" class="imaged w76" style="height: 100%;" />
                            <?php } else { ?>
                                <img src="<?= base_url('assets'); ?>/img/users/profile.png" id="uploaded_image" alt="image" class="imaged w76" style="height: 100%;">
                            <?php } ?>
                            <!-- <input type="file" name="image" class="image" id="upload_image" style="display:none" /> -->
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <!-- Wallet Card -->

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4">
            <div class=" pt-3">
                <ul class="listview image-listview mb-2 bg-transparent">
                    <li class="d-inline-block">
                        <a class="item left d-block" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 text-uppercase m-0 font-weight-bolder">FAQ</h3>
                            </div>
                        </a>
                        <p class="d-block">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore quisquam quos soluta nostrum tenetur obcaecati quo quas iste nihil cupiditate, voluptates eveniet sunt ea, ab dignissimos, quidem enim ratione. Accusantium!
                        </p>
                    </li>
                    <li>
                        <a href="" class="item left">

                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 m-0 font-weight-bolder">Terms and Condition</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="item versi">
                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 m-0 font-weight-bolder">Versi App</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('auth/logout') ?>" class="item logout">
                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 m-0 font-weight-bolder text-danger">Logout</h3>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="mt-5 mb-5 text-center">
                <div class="sosmed-setting">
                    <a href="https://s.id/DiscordBaliola">
                        <img src="<?= base_url('assets'); ?>/img/icon/discord.svg" alt="discord">
                    </a>
                    <a href="https://t.me/kepengindonesiacommunity">
                        <img src="<?= base_url('assets'); ?>/img/icon/telegram.png" alt="telegram">
                    </a>
                </div>
                <div class="footer-title">
                    Nouvarium © <?= date('Y'); ?><br>
                    Powered by Kepeng.io
                </div>
            </div>
        </div>
    </div>
    <!-- * App Capsule -->