<?php
foreach ($all_transaksi as $dt_transaksi) {
    if ($dt_transaksi['sender_id'] <> $data_user['id']) {
        $color = 'success';
        $message = 'Form ';
        $person = $dt_transaksi['sender_name'];
        $simbol = '+';
    } else {
        $color = 'danger';
        $message = 'To ';
        $person = $dt_transaksi['recipient_name'];
        $simbol = '-';
    }
?>
    <!-- Detail Transaksi Action Sheet -->
    <div class="modal fade action-sheet" id="detailActionSheet<?= $dt_transaksi['id_transaksi'] ?>" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header pl-0">
                    <div class="listed-detail mt-3 text-center">
                        <svg width="75" height="75" viewBox="0 0 255 255" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="127.5" cy="127.5" r="127.5" fill="url(#paint0_radial)" />
                            <circle cx="128" cy="128" r="78" fill="#4F5D75" />
                            <path d="M101.833 127.5L121.083 146.75L153.167 108.25" stroke="white" stroke-width="15.4" stroke-linecap="round" stroke-linejoin="round" />
                            <defs>
                                <radialGradient id="paint0_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(127.5 127.5) rotate(90) scale(151.622)">
                                    <stop stop-color="#B5C6E0" />
                                    <stop offset="1" stop-color="#B5C6E0" stop-opacity="0" />
                                </radialGradient>
                            </defs>
                        </svg>
                    </div>
                </div>

                <div class="modal-body">
                    <ul class="listview flush transparent simple-listview no-space mt-3">
                        <li>
                            <strong>Status</strong>
                            <span class="text-success">Success</span>
                        </li>
                        <li>
                            <strong><?= $message; ?></strong>
                            <span><?= $person; ?></span>
                        </li>
                        <li>
                            <strong>Date</strong>
                            <span><?= $dt_transaksi['tanggal'] ?></span>
                        </li>
                        <li>
                            <strong>Amount</strong>
                            <h3 class="m-0 text-<?= $color; ?>"><?= $simbol . ' ' . $dt_transaksi['jumlah'] ?> KPG</h3>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- * Detail Transaksi Action Sheet -->
<?php
}
?>

<?php
if ($this->session->flashdata('securityTransaksi')) {
?>
    <div class="position-fixed alert alert-<?= $this->session->flashdata('color'); ?> mb-2 alert-dismissible fade show" role="alert" style="bottom: 75px; right: 20px; z-index: 999;">
        <strong>Announcement!</strong><br><?= $this->session->flashdata('securityTransaksi'); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
            </svg>
        </button>
    </div>

<?php
}
?>

<!-- Receive Action Sheet -->
<div class="modal fade action-sheet" id="receiveActionSheet" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header pl-0">
                <h2 class="modal-title">Scan QR Code</h2>
            </div>
            <div class="modal-body">
                <div class="action-sheet-content">
                    <div class="qr-code-user">
                        <img src="<?= base_url('qr/users/') . $data_user['kode_qr']; ?>" alt="QR-CODE">
                    </div>
                </div>
            </div>

            <div class="modal-header pl-0">
                <h2 class="modal-title">Wallet Address</h2>
            </div>

            <div class="modal-body">
                <div class="kode-user">
                    <input type="text" class="mb-3 text-center" name="code-qr" id="myCodeQr" value="<?= $data_user['email'] ?>" disabled>
                    <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                    <div class="row">
                        <div class="col-6">
                            <button class="btn btn-md btn-nouva1 btn-block rounded-pill copy" onclick="copyFunction()">Copy</button>
                        </div>
                        <div class="col-6">
                            <a href="#" class="btn btn-md btn-nouva1 btn-block rounded-pill" class="btn btn-md btn-nouva1 btn-block rounded-pill">Share</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- * Receive Action Sheet -->

<!-- Send Action Sheet -->
<div class="modal fade action-sheet" id="sendActionSheet" tabindex="-1" role="dialog" aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="POST" action="<?= base_url('homepage/securityKpg'); ?>" autocomplete="off" autocapitalize="none">
                <div class="modal-header pl-0">
                    <h2 class="modal-title">Wallet Address</h2>
                </div>

                <div class="modal-body">
                    <div class="kode-user">
                        <input type="text" class="mb-3 text-center" name="codeqr" id="codeQrOther" placeholder="example@gmail.com">
                        <div class="row">
                            <div class="col-6">
                                <button type="button" class="btn btn-md btn-nouva1 btn-block rounded-pill">Check account</button>
                            </div>
                            <div class="col-6">
                                <a href="#scanActionSheet" class="btn btn-md btn-nouva1 btn-block rounded-pill" data-dismiss="modal" data-toggle="modal">Scan QR</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-header pl-0 mt-3">
                    <h2 class="modal-title">Amount</h2>
                </div>

                <div class="modal-body">
                    <div class="kode-user">
                        <div class="input-group input-group-nouva1 mb-3 bg-white">
                            <div class="input-group-prepend shadow-none">
                                <div class="input-group-text border-0 text-nouva1">
                                    <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG" class="imaged w24">
                                </div>
                            </div>
                            <input type="text" class="form-control shadow-none" name="amount" id="amount" placeholder="e.g 0.03 / 10">
                            <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                        </div>
                        <button type="submit" class="btn btn-lg btn-nouva1 btn-block rounded-pill">Send</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- * Send Action Sheet -->

<!-- Buy Action Sheet -->
<div class="modal fade action-sheet" id="buyActionSheet" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="">
                <div class="modal-header pl-0">
                    <h2 class="modal-title">COMING SOON</h2>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- * Buy Action Sheet -->

<!-- Scan QR Action Sheet -->
<div class="modal fade action-sheet" id="scanActionSheet" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="">
                <div class="modal-header pl-0">
                    <h2 class="modal-title">COMING SOON</h2>
                    <div class="qr-code-user">
                        <video id="videoku" autoplay class="d-flex align-items-center"></video>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- * Scan QR Action Sheet -->

<script>

</script>

<!-- COPY PASTE -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
<script>
    // Grab elements, create settings, etc.
    var video = document.getElementById('videoku');

    // Get access to the camera!
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // Not adding `{ audio: true }` since we only want video now
        navigator.mediaDevices.getUserMedia({
            video: true
        }).then(function(stream) {
            //video.src = window.URL.createObjectURL(stream);
            video.srcObject = stream;
            video.play();
        });
    }


    scanner.addListener('scan', function(c) {
        document.getElementById('text').value = c;
    });

    var copyQR = '';

    $('.copy').on('click', function() {
        copyQR = $(this).prev().val();
    });

    function copyFunction() {
        var copyID = document.getElementById("myCodeQr");

        copyID.select();
        copyID.setSelectionRange(0, 99999);
        copyQR = copyID.value;

        navigator.clipboard.writeText(copyID.value);
        alert("Copied the Code: " + copyID.value);
    }

    function pasteFunction() {
        document.getElementById("codeQrOther").value = copyQR;
    }
</script>