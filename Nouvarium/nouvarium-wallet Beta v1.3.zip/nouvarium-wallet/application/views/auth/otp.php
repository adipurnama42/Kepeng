<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center">
            <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="" class="logo-nouva1 mb-5">
            <h1>Verification Code</h1>
            <h4>Please look at the WhatsApp for<br>Enter 4 digit verification code. <a href="<?= base_url('auth/resend'); ?>">resend code?</a></h4>
        </div>
        <div class="section mt-2 mb-5 p-3">

            <?php
            if ($this->session->flashdata('messageotp')) {
            ?>
                <div class="alert alert-<?= $this->session->flashdata('color'); ?> mb-2 alert-dismissible fade show" role="alert">
                    <strong>Attention!</strong> <?= $this->session->flashdata('messageotp'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                    </button>
                </div>
            <?php
            }
            if ($this->session->flashdata('otp')) {
            ?>
                <div class="alert alert-<?= $this->session->flashdata('color'); ?> mb-2 alert-dismissible fade show" role="alert">
                    <strong>Attention!</strong> <?= $this->session->flashdata('otp'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                    </button>
                </div>
            <?php
            }
            ?>
            <form action="" method="POST" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <input type="text" name="satu" class="form-control verification-input border-0" id="smscode" placeholder="••••" maxlength="4" style="width: 250px;">
                    <?= form_error('satu', '<small class="text-danger text-center d-block">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Verify</button>
                </div>
            </form>
        </div>

    </div>
    <!-- * App Capsule -->