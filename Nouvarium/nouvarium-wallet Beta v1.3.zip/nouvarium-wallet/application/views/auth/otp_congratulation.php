<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section">
            <div class="splash-page mt-5 mb-5">
                <h1 class="mb-2 text-nouva1">Succeed!</h1>
                <p>
                    Successfully verified,<br>proceed to create a PIN!
                </p>
                <div class="mt-3">
                    <svg width="255" height="255" viewBox="0 0 255 255" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="127.5" cy="127.5" r="127.5" fill="url(#paint0_radial)" />
                        <circle cx="128" cy="128" r="78" fill="#4F5D75" />
                        <path d="M101.833 127.5L121.083 146.75L153.167 108.25" stroke="white" stroke-width="15.4" stroke-linecap="round" stroke-linejoin="round" />
                        <defs>
                            <radialGradient id="paint0_radial" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(127.5 127.5) rotate(90) scale(151.622)">
                                <stop stop-color="#B5C6E0" />
                                <stop offset="1" stop-color="#B5C6E0" stop-opacity="0" />
                            </radialGradient>
                        </defs>
                    </svg>

                </div>
                <div class="mt-5">
                    <a href="<?= base_url('Auth/setting_pin'); ?>" type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Create PIN</a>
                </div>
            </div>
        </div>
    </div>
    <!-- * App Capsule -->