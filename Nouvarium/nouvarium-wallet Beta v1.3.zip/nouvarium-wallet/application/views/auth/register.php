<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader no-border bg-nouva1">
        <div class="left">
            <a href="<?= base_url('auth/index'); ?>" class="headerButton goBack text-nouva1">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center text-nouva1">
            <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="" class="logo-nouva1">
        </div>

        <div class="section mt-2 mb-5 p-3">
            <form method="POST" action="<?= base_url('auth/register'); ?>" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <label for="name" class="text-nouva1 font-weight-bold">Enter Name</label>
                    <input type="text" name="name" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="name" placeholder="" value="<?= set_value('name'); ?>">
                    <?= form_error('name', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="email" class="text-nouva1 font-weight-bold">Enter E-mail</label>
                    <input type="text" name="email" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="email" placeholder="" value="<?= set_value('email'); ?>">
                    <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="phone" class="text-nouva1 font-weight-bold">Enter Phone Number</label>
                    <input type="text" name="phone" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="phone" placeholder="" value="<?= set_value('phone'); ?>">
                    <?= form_error('phone', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password1" class="text-nouva1 font-weight-bold">Enter Password</label>
                    <input type="password" name="password1" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password1" placeholder="" value="">
                    <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password2" class="text-nouva1 font-weight-bold">Re-Enter Password</label>
                    <input type="password" name="password2" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password2" placeholder="" value="">
                    <?= form_error('password2', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Sign
                        Up</button>
                </div>

                <div class="form-group mt-2 text-center text-body">
                    <p>
                        Have an account? <a href="<?= base_url('auth/login'); ?>">Login</a>
                    </p>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->