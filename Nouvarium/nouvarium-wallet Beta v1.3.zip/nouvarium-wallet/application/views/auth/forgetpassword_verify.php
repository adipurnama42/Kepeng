<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader no-border bg-nouva1">
        <div class="left">
            <a href="<?= base_url('auth/forgetPassword'); ?>" class="headerButton goBack text-nouva1">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
            <a href="<?= base_url('auth'); ?>" class="headerButton goBack text-nouva1">
                Login
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center">
            <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="" class="logo-nouva1 mb-5">
            <h1>Verification Code</h1>
            <h4>Code sent to number <?= $phone; ?> via whatsapp to reset the password</h4>
        </div>
        <div class="section mt-2 mb-5 p-3">
            <form action="<?= base_url('auth/forgetpasswordverify'); ?>" method="POST" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <input type="text" name="kode" class="form-control verification-input border-0" id="smscode" placeholder="••••" maxlength="4" style="width: 250px;">
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Verify</button>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->