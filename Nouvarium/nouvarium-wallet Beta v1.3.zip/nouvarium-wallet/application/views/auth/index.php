<body class="bg-nouva-img1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-5">
            <h1>Welcome<br>
                to Nouvarium!</h1>
        </div>

        <div class="section mt-2 mb-5 p-3">
            <?php
            if ($this->session->flashdata('message')) {
            ?>
                <div class="alert alert-danger mb-2 alert-dismissible fade show" role="alert">
                    <strong>Error!</strong> <?= $this->session->flashdata('message'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                    </button>
                </div>

            <?php
            }
            ?>


            <?php
            if ($this->session->flashdata('logout')) {
            ?>
                <div class="alert alert-info mb-2 alert-dismissible fade show" role="alert">
                    <strong>Announcement!</strong><br>You Have been logged out<?= $this->session->flashdata('logout'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                    </button>
                </div>

            <?php
            }
            ?>

            <form method="POST" action="<?= base_url('auth/login'); ?>" autocapitalize="none" autocomplete="off">
                <div class="form-group">
                    <label for="email" class="text-nouva1 font-weight-bold">Enter E-mail</label>
                    <input type="text" name="email" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="email" placeholder="" value="" autocomplete="off">
                    <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password" class="text-nouva1 font-weight-bold">Enter Password</label>
                    <input type="password" name="password" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password" placeholder="" value="" autocomplete="off">
                    <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill" id="loginBtn">Login</button>
                </div>

                <div class="form-group mt-2 text-center text-body">
                    <p>
                        <a href="<?= base_url('auth/forgetPassword'); ?>">Forgot your password?</a><br>
                        or<br>
                        Don’t have an account? <a href="<?= base_url('auth/register'); ?>">Register Here</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
    <!-- * App Capsule -->

    <script>
    </script>