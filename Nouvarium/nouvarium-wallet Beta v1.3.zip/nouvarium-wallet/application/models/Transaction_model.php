<?php


class Transaction_model extends CI_Model
{
    public function getDataUser()
    {
        $id = $this->session->userdata("id");
        $data_user = $this->db->get_where('users', ['id' => $id])->row_array();
        return $data_user;
    }

    public function KpgSender()
    {
        $id = $this->session->userdata("id");
        $data_user = $this->db->get_where('users_dompet', ['id_users' => $id])->row_array();
        return $data_user;
    }

    public function getDataRecipent($recip)
    {
        $data_user_recip = $this->db->get_where('users', ['id' => $recip])->row_array();
        return $data_user_recip;
    }

    public function KpgRecipient($recip)
    {
        $data_user_recip = $this->db->get_where('users', ['email' => $recip])->row_array();
        $data_user = $this->db->get_where('users_dompet', ['id_users' => $data_user_recip['id']])->row_array();
        return $data_user;
    }

    public function securityKpg($code, $amount)
    {
        $sender = $this->KpgSender();
        $send_saldo =  $sender['saldo'] - $amount;
        if ($send_saldo < 0) {
            return 0;
        } else {
            $transaksi = [
                "code" => $code,
                "saldo" => $send_saldo,
                "amount" => $amount
            ];
            $this->session->set_userdata($transaksi);
            return 1;
        }
    }

    public function securityPIN($pin)
    {
        $sender = $this->getDataUser();

        if ($sender['user_pin'] <> $pin) {
            return 0;
        } else {
            $this->sendKpg($this->session->userdata('saldo'));
            return 1;
        }
    }

    public function sendKpg($send_saldo)
    {
        $sender = $this->KpgSender();

        date_default_timezone_set('Asia/Makassar');
        $startTime = date("Y-m-d H:i:s");

        $data =
            [
                "saldo" => $send_saldo
            ];

        $this->db->where('id_dompet', $sender['id_dompet']);
        $result = $this->db->update('users_dompet', $data);

        if ($result != NULL) {
            $recip = $this->KpgRecipient($this->session->userdata('code'));
            $recip_name = $this->getDataRecipent($recip['id_users']);
            $receive_saldo = $recip['saldo'] + $this->input->post('amount',  TRUE);
            $data =
                [
                    "saldo" => $receive_saldo
                ];
            $this->db->where('id_dompet', $recip['id_dompet']);
            $result = $this->db->update('users_dompet', $data);

            if ($result != NULL) {
                $recip = $this->KpgRecipient($this->session->userdata('code'));
                $data =
                    [
                        "sender_id" => $sender['id_users'],
                        "recipient_id" => $recip['id_users'],
                        "status" => "Yes",
                        "tanggal" => $startTime,
                        "jumlah" => $this->session->userdata('amount'),
                        "kategori" => "Send"
                    ];
                $receive_info = [
                    "name_receive" => $recip_name['name']
                ];
                $this->session->set_userdata($receive_info);
                $this->db->insert('users_transaksi', $data);
                return 1;
            } else {
                $data =
                    [
                        "sender_id" => $sender['id_users'],
                        "recipient_id" => $recip['id_users'],
                        "status" => "No",
                        "tanggal" => $startTime,
                        "jumlah" => $this->session->userdata('amount'),
                        "kategori" => "Send"
                    ];
                $this->db->insert('users_transaksi', $data);
                $this->session->set_flashdata('flash', 'Saldo gagal diterima');
                $this->session->set_flashdata('color', 'danger');
            }
        } else {
            $this->session->set_flashdata('flash', 'Saldo gagal dikirim');
            $this->session->set_flashdata('color', 'danger');
        }
    }
}
