<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Discount extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();

        $this->load->model('User_model', 'User');
        $this->load->library('form_validation');

        if (!$this->session->userdata('id')) {
            redirect('auth');
        } else {
            $data_user = $this->User->getDataHome($this->session->userdata('id'));
            if ($data_user == NULL) {
                redirect('homepage');
            }
        }
    }

    public function index()
    {
        $id = $this->session->userdata("id");

        $data["data_user"] = $this->User->getDataHome($id);
        $data["data_dompet_user"] = $this->User->getDataUsers($id);
        $data['title'] = "Discount";

        $this->load->view('templates/headerauth', $data);
        $this->load->view('user/discount', $data);
        $this->load->view('templates/modal', $data);
        $this->load->view('templates/navbottom');
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/footer');
    }
}
