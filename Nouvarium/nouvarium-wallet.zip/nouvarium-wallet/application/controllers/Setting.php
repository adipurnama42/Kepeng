<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Setting extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();

        $this->load->model('User_model', 'User');
        $this->load->library('form_validation');

        if (!$this->session->userdata('id')) {
            redirect('auth');
        } else {
            $data_user = $this->User->getDataHome($this->session->userdata('id'));
            if ($data_user == NULL) {
                redirect('homepage');
            }
        }
    }

    public function index()
    {
        $id = $this->session->userdata("id");

        $data["data_user"] = $this->User->getDataHome($id);
        $data['title'] = "Setting";

        $this->load->view('templates/headerauth', $data);
        $this->load->view('user/setting', $data);
        $this->load->view('templates/navbottom');
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/footer');
    }

    public function profile()
    {
        $id = $this->session->userdata("id");
        $data["data_user"] = $this->User->getDataHome($id);
        $data['title'] = "Setting";

        $this->form_validation->set_rules('name', 'Nama', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('user/setting', $data);
            $this->load->view('templates/navbottom');
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/footer');
        } else {
            $this->User->updateprofile1($id);
            redirect('setting');
        }
    }
}
