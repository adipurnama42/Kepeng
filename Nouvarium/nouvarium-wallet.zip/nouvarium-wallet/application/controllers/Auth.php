<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Auth_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        if ($this->session->userdata('id')) {
            redirect('Homepage');
        }
        // $this->load->view('welcome');

        $data['title'] = "Nouvarium Wallet - Login";

        $this->load->view('templates/headerauth', $data);
        $this->load->view('auth/index', $data);
        $this->load->view('templates/footer');
    }

    public function login()
    {
        if ($this->session->userdata('id')) {
            redirect('Homepage');
        }
        // $this->load->view('welcome');

        $data['title'] = "Nouvarium Wallet - Login";

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/index', $data);
            $this->load->view('templates/footer');
        } else {
            $this->_login();
        }
    }

    public function _login()
    {
        $username = $this->input->post("email");
        $password = $this->input->post("password");
        $user = $this->db->get_where('users', ['email' => $username])->row_array();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $data = [
                    'name' => $user['name'],
                    'id' => $user['id']
                ];
                $this->session->set_userdata($data);

                redirect('Homepage');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Is not valid</div>');
                redirect('Auth/login');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email Tidak Terdaftar</div>');
            redirect('Auth/login');
        }
    }


    public function register()
    {
        if ($this->session->userdata('id')) {
            redirect('Homepage');
        }

        $data['title'] = "Nouvarium Wallet - Sign Up";

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required|numeric');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password1', 'First Password', 'required|min_length[5]');
        $this->form_validation->set_rules('password2', 'Second Password', 'required|min_length[5]|matches[password1]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/register', $data);
            $this->load->view('templates/footer');
        } else {

            $add = $this->Auth_model->addUser();

            if ($add == 1) {
                redirect('auth/otp');
            } else {
                $this->session->flashdata('error');
                redirect('auth/register');
            }
        }
    }


    public function otp()
    {
        $date = $this->session->userdata('date');
        $id = $this->session->userdata('id');

        $data['title'] = "Nouvarium Wallet";
        $this->form_validation->set_rules('satu', 'OTP', 'required|min_length[4]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/otp', $data);
            $this->load->view('templates/footer');
        } else {
            $result = $this->Auth_model->verifOtp();

            if ($result > 0) {
                redirect('Auth/otp_ok');
            } else {
                $this->session->set_flashdata('flash', 'Sorry, Wrong OTP Code !! Please Fill Correctly');
                $this->session->set_flashdata('color', 'danger');
                redirect('auth/otp');
            }
        }
    }

    public function otp_ok()
    {

        $data['title'] = "Nouvarium Wallet";
        $this->load->view('templates/headerauth', $data);
        $this->load->view('auth/otp_congratulation', $data);
        $this->load->view('templates/footer');
    }

    public function resend()
    {
        $id = $this->session->userdata('id');
        $this->Auth_model->resendOtp($id);
        redirect('auth/otp');
    }

    public function setting_pin()
    {
        $this->form_validation->set_rules('kode', 'kode', 'required|min_length[6]');

        if ($this->form_validation->run() == FALSE) {
            $data['title'] = "Nouvarium Wallet";
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/setting_pin', $data);
            $this->load->view('templates/footer');
        } else {
            $this->session->set_userdata('kode', $this->input->post('kode', true));
            redirect('auth/setting_pin2');
        }
    }

    public function setting_pin2()
    {
        $this->form_validation->set_rules('kode', 'kode', 'required|min_length[5]');
        if ($this->form_validation->run() == FALSE) {
            $data['title'] = "Nouvarium Wallet";
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/setting_pin2', $data);
            $this->load->view('templates/footer');
        } else {
            $kode1 = $this->session->userdata('kode');
            $kode2 = $this->input->post('kode');

            if ($kode1 == $kode2) {

                $id = $this->session->userdata('id');

                $this->db->set('user_pin', $kode2);
                $this->db->where('id', $id);
                $result = $this->db->update('users');

                if ($result) {
                    $data =
                        [
                            "id_users" => $id,
                            "saldo" => '0'
                        ];
                    $this->db->insert('users_dompet', $data);

                    redirect('auth/setting_pinok');
                }
            } else {
                $this->session->set_flashdata('flash', 'Sorry, Wrong PIN Code !! Please Fill Correctly Maaf');
                $this->session->set_flashdata('color', 'danger');
                redirect('auth/setting_pin2');
            }
        }
    }

    public function setting_pinok()
    {
        $data['title'] = "Nouvarium Wallet";
        $this->load->view('templates/headerauth', $data);
        $this->load->view('auth/setting_pin_ok', $data);
        $this->load->view('templates/footer');
    }

    public function logout()
    {
        $this->session->unset_userdata('name');
        $this->session->unset_userdata('id');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">You Have been logged out </div>');
        redirect('Auth');
    }

    function forgetPassword()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $data['title'] = "Nouvarium Wallet";

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/forgetpassword', $data);
            $this->load->view('templates/footer');
        } else {
            $id_user = $this->Auth_model->checkEmail();
            $this->Auth_model->resendOtpPassword($id_user);
            redirect('auth/forgetpasswordverify');
        }
    }

    function forgetpasswordverify()
    {
        $this->form_validation->set_rules('kode', 'kode', 'required|min_length[4]');
        $data['phone'] = $this->Auth_model->showNomorPhone();
        $data['title'] = "Nouvarium Wallet";

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/forgetpassword_verify', $data);
            $this->load->view('templates/footer');
        } else {
            $result = $this->Auth_model->checkOtp();

            if ($result > 0) {
                redirect('Auth/resetPasswordnew');
            } else {
                $this->session->set_flashdata('flash', 'Sorry, Wrong OTP Code !! Please Fill Correctly');
                $this->session->set_flashdata('color', 'danger');
                redirect('auth/forgetpassword_verify');
            }
        }
    }

    function resetPasswordnew()
    {
        $this->form_validation->set_rules('password1', 'First Password', 'required|min_length[5]');
        $this->form_validation->set_rules('password2', 'Second Password', 'required|min_length[5]|matches[password1]');
        $data['title'] = "Nouvarium Wallet";

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('auth/resetpassword', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Auth_model->resetPassword();
            $this->session->unset_userdata('id_reset');
            redirect('auth/resetPasswordsukses');
        }
    }

    public function resetPasswordsukses()
    {
        $data['title'] = "Nouvarium Wallet";
        $this->load->view('templates/headerauth', $data);
        $this->load->view('auth/resetpasswordsukses', $data);
        $this->load->view('templates/footer');
    }
}
