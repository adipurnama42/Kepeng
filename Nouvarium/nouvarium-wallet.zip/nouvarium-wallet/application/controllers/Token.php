<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Token extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();

        $this->load->model('User_model', 'User');
        $this->load->library('form_validation');

        if (!$this->session->userdata('id')) {
            redirect('auth');
        } else {
            $data_user = $this->User->getDataHome($this->session->userdata('id'));
            if ($data_user == NULL) {
                redirect('homepage');
            }
        }
    }

    public function index()
    {
        $id = $this->session->userdata("id");

        $data["data_user"] = $this->User->getDataHome($id);
        $data['title'] = "Token";

        $this->load->view('templates/headerauth', $data);
        $this->load->view('user/token', $data);
        $this->load->view('templates/navbottom');
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/footer');
    }
}
