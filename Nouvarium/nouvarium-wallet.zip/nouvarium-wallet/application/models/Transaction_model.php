<?php


class Transaction_model extends CI_Model
{
    public function KpgSender()
    {
        $id = $this->session->userdata("id");
        $data_user = $this->db->get_where('users_dompet', ['id_users' => $id])->row_array();
        return $data_user;
    }

    public function KpgRecipient($recip)
    {
        $data_user_recip = $this->db->get_where('users', ['email' => $recip])->row_array();
        $data_user = $this->db->get_where('users_dompet', ['id_users' => $data_user_recip['id']])->row_array();
        return $data_user;
    }

    public function sendKpg()
    {
        $sender = $this->KpgSender();
        $send_saldo =  $sender['saldo'] - $this->input->post('amount',  TRUE);

        date_default_timezone_set('Asia/Makassar');
        $startTime = date("Y-m-d H:i:s");

        if ($send_saldo < 0) {
            $this->session->set_flashdata('flash', 'Saldo tidak cukup');
            $this->session->set_flashdata('color', 'danger');
        } else {
            $data =
                [
                    "saldo" => $send_saldo
                ];
            $this->db->where('id_dompet', $sender['id_dompet']);
            $result = $this->db->update('users_dompet', $data);

            if ($result != NULL) {
                $recip = $this->KpgRecipient($this->input->post('codeqr',  TRUE));
                $receive_saldo = $recip['saldo'] + $this->input->post('amount',  TRUE);
                $data =
                    [
                        "saldo" => $receive_saldo
                    ];
                $this->db->where('id_dompet', $recip['id_dompet']);
                $result = $this->db->update('users_dompet', $data);
                if ($result != NULL) {
                    $recip = $this->KpgRecipient($this->input->post('codeqr',  TRUE));
                    $data =
                        [
                            "sender_id" => $sender['id_users'],
                            "recipient_id" => $recip['id_users'],
                            "status" => "",
                            "tanggal" => $startTime,
                            "jumlah" => $this->input->post('amount',  TRUE),
                            "kategori" => ""
                        ];

                    $this->db->insert('users_transaksi', $data);
                    return 1;
                } else {
                    $this->session->set_flashdata('flash', 'Saldo gagal diterima');
                    $this->session->set_flashdata('color', 'danger');
                }
            } else {
                $this->session->set_flashdata('flash', 'Saldo gagal dikirim');
                $this->session->set_flashdata('color', 'danger');
            }
        }
    }
}
