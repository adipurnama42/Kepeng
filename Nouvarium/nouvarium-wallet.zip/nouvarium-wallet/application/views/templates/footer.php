<!-- ///////////// Js Files ////////////////////  -->
<!-- Jquery -->
<script src="<?= base_url(''); ?>assets/js/lib/jquery-3.4.1.min.js"></script>
<!-- Bootstrap-->
<script src="<?= base_url(''); ?>assets/js/lib/popper.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/lib/bootstrap.min.js"></script>
<!-- Ionicons -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<!-- Owl Carousel -->
<script src="<?= base_url(''); ?>assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
<!-- Base Js File -->
<script src="<?= base_url(''); ?>assets/js/base.js"></script>

<script>
    function forceLower(strInput) {
        strInput.value = strInput.value.toLowerCase();
    }​
</script>


</body>

</html>