<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $title; ?></title>
    <link rel="stylesheet" href="<?= base_url(''); ?>assets/css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Finapp HTML Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, cordova, phonegap, mobile, html, responsive" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('assets/'); ?>assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="<?= base_url('assets/'); ?>assets/img/favicon.png" sizes="32x32">
    <link rel="shortcut icon" href="<?= base_url('assets/'); ?>assets/img/favicon.png">
</head>

<body>