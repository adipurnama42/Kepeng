<!-- App Bottom Menu -->
<div class="appBottomMenu no-border">
    <a href="<?= base_url('homepage'); ?>" class="item active">
        <div class="col">
            <img src="<?= base_url('assets'); ?>/img/icon/Transaction.svg" alt="home">
            <strong>Transaction</strong>
        </div>
    </a>
    <a href="<?= base_url('token'); ?>" class="item">
        <div class="col">
            <img src="<?= base_url('assets'); ?>/img/icon/Token.svg" alt="home">
            <strong>Tokens</strong>
        </div>
    </a>
    <a href="<?= base_url('collectibles'); ?>" class="item">
        <div class="col">
            <img src="<?= base_url('assets'); ?>/img/icon/Collectibles.svg" alt="home">
            <strong>Collectibles</strong>
        </div>
    </a>
    <a href="<?= base_url('setting'); ?>" class="item">
        <div class="col">
            <img src="<?= base_url('assets'); ?>/img/icon/Settings.svg" alt="home">
            <strong>Settings</strong>
        </div>
    </a>
</div>
<!-- * App Bottom Menu -->