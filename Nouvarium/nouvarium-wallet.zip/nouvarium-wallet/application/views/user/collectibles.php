<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">

        <!-- Wallet Card -->
        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-8">
                    <span class="title-name text-nouva1"><?= $data_user['name']; ?></span>
                    <span class="code-id">3271FHV897KHB1319699S</span>
                </div>
                <div class="col-4">
                    <div class="profile-img">
                        <img src="<?= base_url('assets'); ?>/img/users/profile.png" alt="image" class="imaged">
                    </div>
                </div>
                <div class="col-12">
                    <div class="balance-kpg text-nouva1">
                        <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG">
                        <span>100.01 KPG</span><br>
                        <span class="tittle-today">$100 Today</span>
                    </div>
                </div>

                <div class="col-12 wallet-card bg-transparent border-0 shadow-none m-0 p-0">
                    <div class="wallet-footer border-0">
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#receiveActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/receive-icon.svg" alt="Receive">
                                </div>
                                <strong>Receive</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#sendActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/send-icon.svg" alt="Receive">
                                </div>
                                <strong>Send</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#buyActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/buy-icon.svg" alt="Receive">
                                </div>
                                <strong>Buy</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#scanActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/Scan.svg" alt="Receive">
                                </div>
                                <strong>Scan</strong>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Wallet Card -->

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4">
            <h2 class="title text-nouva1 mb-2 text-center">Collectibles</h2>
            <h2 class="title text-nouva1 mb-2 text-center">COMING SOON</h2>
        </div>
        <!-- * Transactions -->

    </div>
    <!-- * App Capsule -->

    <!-- Receive Action Sheet -->
    <div class="modal fade action-sheet" id="receiveActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header pl-0">
                    <h2 class="modal-title">Scan QR Code</h2>
                </div>
                <div class="modal-body">
                    <div class="action-sheet-content">
                        <div class="qr-code-user">
                            <img src="<?= base_url('qr'); ?>/munirrmiftahul94@gmail.com.png" alt="QR-CODE">
                        </div>
                    </div>
                </div>

                <div class="modal-header pl-0">
                    <h2 class="modal-title">Wallet Address</h2>
                </div>

                <div class="modal-body">
                    <div class="kode-user">
                        <input type="text" class="mb-3 text-center" name="code-qr" id="myCodeQr" value="3271FHV897KHB1319699S" disabled>
                        <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                        <div class="row">
                            <div class="col-6">
                                <button class="btn btn-md btn-nouva1 btn-block rounded-pill copy" onclick="copyFunction()">Copy</button>
                            </div>
                            <div class="col-6">
                                <a href="#" class="btn btn-md btn-nouva1 btn-block rounded-pill">Scan QR</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- * Receive Action Sheet -->

    <!-- Send Action Sheet -->
    <div class="modal fade action-sheet" id="sendActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="">
                    <div class="modal-header pl-0">
                        <h2 class="modal-title">Wallet Address</h2>
                    </div>

                    <div class="modal-body">
                        <div class="kode-user">
                            <input type="text" class="mb-3 text-center" name="code-qr" id="codeQrOther" value="">
                            <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                            <div class="row">
                                <div class="col-6">
                                    <button type="button" class="btn btn-md btn-nouva1 btn-block rounded-pill" onclick="pasteFunction()">Paste</button>
                                </div>
                                <div class="col-6">
                                    <a href="#" class="btn btn-md btn-nouva1 btn-block rounded-pill">Share</a>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="modal-header pl-0 mt-3">
                        <h2 class="modal-title">Amount</h2>
                    </div>

                    <div class="modal-body">
                        <div class="kode-user">
                            <div class="input-group input-group-nouva1 mb-3 bg-white">
                                <div class="input-group-prepend shadow-none">
                                    <div class="input-group-text border-0 text-nouva1">$</div>
                                </div>
                                <input type="text" class="form-control shadow-none" name="code-qr" id="code-qr" value="">
                                <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                            </div>
                            <button type="submit" class="btn btn-lg btn-nouva1 btn-block rounded-pill">Send</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- * Send Action Sheet -->

    <!-- Buy Action Sheet -->
    <div class="modal fade action-sheet" id="buyActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="">
                    <div class="modal-header pl-0">
                        <h2 class="modal-title">COMING SOON</h2>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- * Buy Action Sheet -->

    <!-- Scan QR Action Sheet -->
    <div class="modal fade action-sheet" id="scanActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="">
                    <div class="modal-header pl-0">
                        <h2 class="modal-title">COMING SOON</h2>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- * Scan QR Action Sheet -->


    <!-- COPY PASTE -->

    <script>
        var copyQR = '';

        $('.copy').on('click', function() {
            copyQR = $(this).prev().val();
        });

        function copyFunction() {
            var copyID = document.getElementById("myCodeQr");

            copyID.select();
            copyID.setSelectionRange(0, 99999);
            copyQR = copyID.value;

            navigator.clipboard.writeText(copyID.value);
            alert("Copied the Code: " + copyID.value);
        }

        function pasteFunction() {
            document.getElementById("codeQrOther").value = copyQR;
        }
    </script>