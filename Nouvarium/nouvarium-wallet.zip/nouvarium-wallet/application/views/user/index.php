<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">

        <!-- Wallet Card -->
        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-8">
                    <span class="title-name text-nouva1"><?= $data_user['name']; ?></span>
                    <span class="code-id"><?= $data_user['email']; ?></span>
                </div>
                <div class="col-4">
                    <div class="profile-img">
                        <?php if ($data_user["photo_profile"] != NULL) { ?>
                            <img src="<?= base_url('assets/img/users/' . $data_user['photo_profile']) ?>" alt="image" class="imaged w76" style="height: 100%;" />
                        <?php } else { ?>
                            <img src="<?= base_url('assets'); ?>/img/users/profile.png" alt="image" class="imaged w76" style="height: 100%;">
                        <?php } ?>
                    </div>
                </div>
                <div class="col-12">
                    <div class="balance-kpg text-nouva1">
                        <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG">
                        <span><?= number_format($data_dompet_user['saldo'], 2, '.', ','); ?> KPG</span><br>
                        <span class="tittle-today">$0 Today</span>
                    </div>
                </div>

                <div class="col-12 wallet-card bg-transparent border-0 shadow-none m-0 p-0">
                    <div class="wallet-footer border-0">
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#receiveActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/receive-icon.svg" alt="Receive">
                                </div>
                                <strong>Receive</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#sendActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/send-icon.svg" alt="Receive">
                                </div>
                                <strong>Send</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#buyActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/buy-icon.svg" alt="Receive">
                                </div>
                                <strong>Buy</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#scanActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/Scan.svg" alt="Receive">
                                </div>
                                <strong>Scan</strong>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Wallet Card -->

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4 pb-5">
            <h2 class="title text-nouva1 mb-2">Transactions</h2>
            <div class="row">
                <div class="nav col-12 d-flex justify-content-start" role="tablist">
                    <a class="transactions-fitur" id="all-tab" data-toggle="tab" href="#all" role="tab" aria-controls="all" aria-selected="true">All</a>
                    <a class="transactions-fitur text-success" id="in-tab" data-toggle="tab" href="#in" role="tab" aria-controls="in" aria-selected="false">In</a>
                    <a class="transactions-fitur text-danger" id="out-tab" data-toggle="tab" href="#out" role="tab" aria-controls="out" aria-selected="false">Out</a>
                </div>
            </div>

            <div class="mt-5">
                <h4 class="title text-nouva1 text-uppercase mb-2 font-weight-bold">Today</h4>
                <div class="transactions">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                            <?php
                            if ($data_transaksi) {
                                foreach ($data_transaksi as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $nama_transaksi_kirim['name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                        <div class="tab-pane fade" id="in" role="tabpanel" aria-labelledby="in-tab">
                            <?php
                            if ($data_transaksi_terima) {
                                foreach ($data_transaksi_terima as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $data_transaksi_kirim['name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                        <div class="tab-pane fade" id="out" role="tabpanel" aria-labelledby="out-tab">
                            <?php
                            if ($data_transaksi_kirim) {
                                foreach ($data_transaksi_kirim as $transakasi) {
                                    if ($transakasi['sender_id'] <> $data_user['id']) {
                                        $color = 'success';
                                        $keterangan = 'Receive';
                                        $message = 'Form ' . $transakasi['name'];
                                        $icon = 'receive-icon.svg';
                                        $simbol = '+';
                                    } else {
                                        $color = 'danger';
                                        $keterangan = 'Send';
                                        $message = 'To ' . $nama_transaksi_kirim['name'];
                                        $icon = 'send-icon.svg';
                                        $simbol = '-';
                                    }
                            ?>
                                    <!-- item -->
                                    <a href="#" class="item item-nouva1">
                                        <div class="detail">
                                            <img src="<?= base_url('assets'); ?>/img/icon/<?= $icon; ?>" alt="Receive" class="image-block w16">
                                            <div>
                                                <strong><?= $keterangan; ?></strong>
                                                <p><?= $message; ?> </p>
                                            </div>
                                        </div>
                                        <div class="right text-center">
                                            <div class="price text-<?= $color; ?>"> <?= $simbol . ' ' . $transakasi['jumlah']; ?> KPG</div>
                                            <!-- <div class="price-info">12 KPG Today</div> -->
                                        </div>
                                    </a>
                                    <!-- * item -->
                                <?php
                                }
                            } else {
                                ?>
                                <div class="col-12 d-flex justify-content-center">
                                    <a class="transactions-fitur d-inline-block mr-0">
                                        No Transactions
                                    </a>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>

                </div>
            </div>

            <div class="mt-3">
                <div class="col-12 mt-3 mb-3 d-flex justify-content-center" role="tablist">
                    <a href="" class="transactions-fitur d-inline-block mr-0">
                        View all
                    </a>
                </div>
            </div>
        </div>
        <!-- * Transactions -->

    </div>
    <!-- * App Capsule -->

    <!-- Receive Action Sheet -->
    <div class="modal fade action-sheet" id="receiveActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header pl-0">
                    <h2 class="modal-title">Scan QR Code</h2>
                </div>
                <div class="modal-body">
                    <div class="action-sheet-content">
                        <div class="qr-code-user">
                            <img src="<?= base_url('qr/users/') . $data_user['kode_qr']; ?>" alt="QR-CODE">
                        </div>
                    </div>
                </div>

                <div class="modal-header pl-0">
                    <h2 class="modal-title">Wallet Address</h2>
                </div>

                <div class="modal-body">
                    <div class="kode-user">
                        <input type="text" class="mb-3 text-center" name="code-qr" id="myCodeQr" value="<?= $data_user['email'] ?>" disabled>
                        <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                        <div class="row">
                            <div class="col-6">
                                <button class="btn btn-md btn-nouva1 btn-block rounded-pill copy" onclick="copyFunction()">Copy</button>
                            </div>
                            <div class="col-6">
                                <a href="#" class="btn btn-md btn-nouva1 btn-block rounded-pill">Share</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- * Receive Action Sheet -->

    <!-- Send Action Sheet -->
    <div class="modal fade action-sheet" id="sendActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form method="POST" action="<?= base_url('homepage/sendkepeng'); ?>" autocomplete="off" autocapitalize="none">
                    <div class="modal-header pl-0">
                        <h2 class="modal-title">Wallet Address</h2>
                    </div>

                    <div class="modal-body">
                        <div class="kode-user">
                            <input type="text" class="mb-3 text-center" name="codeqr" id="codeQrOther">
                            <div class="row">
                                <div class="col-6">
                                    <button type="button" class="btn btn-md btn-nouva1 btn-block rounded-pill" onclick="pasteFunction()">Paste</button>
                                </div>
                                <div class="col-6">
                                    <a href="#scanActionSheet" class="btn btn-md btn-nouva1 btn-block rounded-pill" data-dismiss="modal" data-toggle="modal">Scan QR</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-header pl-0 mt-3">
                        <h2 class="modal-title">Amount</h2>
                    </div>

                    <div class="modal-body">
                        <div class="kode-user">
                            <div class="input-group input-group-nouva1 mb-3 bg-white">
                                <div class="input-group-prepend shadow-none">
                                    <div class="input-group-text border-0 text-nouva1">
                                        <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG" class="imaged w24">
                                    </div>
                                </div>
                                <input type="text" class="form-control shadow-none" name="amount" id="amount">
                                <!-- <a href="#" class="mb-3">3271FHV897KHB1319699S</a> -->
                            </div>
                            <button type="submit" class="btn btn-lg btn-nouva1 btn-block rounded-pill">Send</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- * Send Action Sheet -->

    <!-- Buy Action Sheet -->
    <div class="modal fade action-sheet" id="buyActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="">
                    <div class="modal-header pl-0">
                        <h2 class="modal-title">COMING SOON</h2>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- * Buy Action Sheet -->

    <!-- Scan QR Action Sheet -->
    <div class="modal fade action-sheet" id="scanActionSheet" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="">
                    <div class="modal-header pl-0">
                        <h2 class="modal-title">COMING SOON</h2>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- * Scan QR Action Sheet -->


    <!-- COPY PASTE -->

    <script>
        var copyQR = '';

        $('.copy').on('click', function() {
            copyQR = $(this).prev().val();
        });

        function copyFunction() {
            var copyID = document.getElementById("myCodeQr");

            copyID.select();
            copyID.setSelectionRange(0, 99999);
            copyQR = copyID.value;

            navigator.clipboard.writeText(copyID.value);
            alert("Copied the Code: " + copyID.value);
        }

        function pasteFunction() {
            document.getElementById("codeQrOther").value = copyQR;
        }
    </script>