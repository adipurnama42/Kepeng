<body class="bg-nouva-img1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-5">
            <h1>Welcome<br>
                to Nouvarium!</h1>
        </div>

        <div class="section mt-2 mb-5 p-3">
            <form method="POST" action="<?= base_url('auth/login'); ?>" autocapitalize="none" autocomplete="off">
                <div class="form-group">
                    <label for="email" class="text-nouva1 font-weight-bold">Enter E-mail</label>
                    <input type="text" name="email" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="email" placeholder="" value="" autocomplete="off">
                    <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password" class="text-nouva1 font-weight-bold">Enter Password</label>
                    <input type="password" name="password" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password" placeholder="" value="" autocomplete="off">
                    <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill" id="loginBtn">Login</button>
                </div>

                <div class="form-group mt-2 text-center text-body">
                    <p>
                        <a href="<?= base_url('auth/forgetPassword'); ?>">Forgot your password?</a><br>
                        or<br>
                        Don’t have an account? <a href="<?= base_url('auth/register'); ?>">Register Here</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
    <!-- * App Capsule -->

    <script>
    </script>