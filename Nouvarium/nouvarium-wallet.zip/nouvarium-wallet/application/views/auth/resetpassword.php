<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader no-border bg-nouva1">
        <div class="left">
            <a href="<?= base_url('auth/index'); ?>" class="headerButton goBack text-nouva1">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
            <a href="<?= base_url('auth/index'); ?>" class="headerButton goBack text-nouva1">
                Login
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center text-nouva1">
            <img src="<?= base_url('auth/forgetPassword'); ?>assets/img/logo-1.png" alt="" class="logo-nouva1">
        </div>
        <div class="section mt-5 text-center text-nouva1">
            <h2 class="mb-2">Reset your password</h2>
        </div>

        <div class="section mt-2 mb-5 p-3">
            <form method="POST" action="<?= base_url('auth/resetPasswordnew'); ?>" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <label for="password1" class="text-nouva1 font-weight-bold">Enter New Password</label>
                    <input type="password" name="password1" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password1" placeholder="" value="">
                    <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password2" class="text-nouva1 font-weight-bold">Enter New Password Again</label>
                    <input type="password" name="password2" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password2" placeholder="" value="">
                    <?= form_error('password2', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Reset Password</button>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->