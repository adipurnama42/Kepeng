<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
</head>

<body>

	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id hic maxime sed, earum quibusdam rem commodi sunt mollitia ipsam consequatur reiciendis quae explicabo expedita dolorem error placeat asperiores quam animi!</p>

</body>

</html>