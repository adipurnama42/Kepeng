<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">

        <!-- Wallet Card -->
        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-12">
                    <div class="profile-img edit">
                        <label for="upload_image">
                            <?php if ($data_user["photo_profile"] != NULL) { ?>
                                <img src="<?= base_url('assets/img/users/' . $data_user['photo_profile']) ?>" id="uploaded_image" alt="image" class="imaged w76" style="height: 100%;" />
                            <?php } else { ?>
                                <img src="<?= base_url('assets'); ?>/img/users/profile.png" id="uploaded_image" alt="image" class="imaged w76" style="height: 100%;">
                            <?php } ?>
                            <!-- <input type="file" name="image" class="image" id="upload_image" style="display:none" /> -->
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <!-- Wallet Card -->

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4">
            <div class="kode-user">
                <div class="">
                    <h2 class="title text-nouva1 text-uppercase mb-2">Settings</h2>
                    <form method="POST" action="<?= base_url('setting/profile') ?>" autocomplete="off" autocapitalize="none">
                        <div class="input-group input-group-nouva1 mb-3 bg-white">
                            <div class="input-group-prepend shadow-none">
                                <div class="input-group-text border-0 text-nouva1">
                                    <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.474 3.40783L15.592 5.52483L13.474 3.40783ZM14.836 1.54283L9.109 7.26983C8.81309 7.56533 8.61128 7.94181 8.529 8.35183L8 10.9998L10.648 10.4698C11.058 10.3878 11.434 10.1868 11.73 9.89083L17.457 4.16383C17.6291 3.99173 17.7656 3.78742 17.8588 3.56256C17.9519 3.33771 17.9998 3.09671 17.9998 2.85333C17.9998 2.60994 17.9519 2.36895 17.8588 2.14409C17.7656 1.91923 17.6291 1.71492 17.457 1.54283C17.2849 1.37073 17.0806 1.23421 16.8557 1.14108C16.6309 1.04794 16.3899 1 16.1465 1C15.9031 1 15.6621 1.04794 15.4373 1.14108C15.2124 1.23421 15.0081 1.37073 14.836 1.54283V1.54283Z" stroke="#4F5D75" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M16 13V16C16 16.5304 15.7893 17.0391 15.4142 17.4142C15.0391 17.7893 14.5304 18 14 18H3C2.46957 18 1.96086 17.7893 1.58579 17.4142C1.21071 17.0391 1 16.5304 1 16V5C1 4.46957 1.21071 3.96086 1.58579 3.58579C1.96086 3.21071 2.46957 3 3 3H6" stroke="#4F5D75" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </div>
                            </div>
                            <input type="text" class="form-control shadow-none" name="name" id="name" value="<?= $data_user['name']; ?>">
                        </div>

                        <div class="input-group input-group-nouva1 mb-3 bg-white" style="background-color: #e9ecef !important;">
                            <div class="input-group-prepend shadow-none">
                                <div class="input-group-text border-0 text-nouva1">
                                    <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M18 1H2C1.44772 1 1 1.44772 1 2V14C1 14.5523 1.44772 15 2 15H18C18.5523 15 19 14.5523 19 14V2C19 1.44772 18.5523 1 18 1Z" stroke="#4F5D75" stroke-width="2" stroke-linecap="round" />
                                        <path d="M1 2.5L10 8L19 2.5" stroke="#4F5D75" stroke-width="2" stroke-linecap="round" />
                                    </svg>
                                </div>
                            </div>
                            <input type="text" class="form-control shadow-none" name="email" id="email" value="<?= $data_user['email']; ?>" disabled>
                        </div>

                        <div class="input-group input-group-nouva1 mb-3 bg-white">
                            <div class="input-group-prepend shadow-none">
                                <div class="input-group-text border-0 text-nouva1">
                                    <svg width="12" height="20" viewBox="0 0 12 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3 0H9C9.79565 0 10.5587 0.316071 11.1213 0.87868C11.6839 1.44129 12 2.20435 12 3V17C12 17.7956 11.6839 18.5587 11.1213 19.1213C10.5587 19.6839 9.79565 20 9 20H3C2.20435 20 1.44129 19.6839 0.87868 19.1213C0.316071 18.5587 0 17.7956 0 17V3C0 2.20435 0.316071 1.44129 0.87868 0.87868C1.44129 0.316071 2.20435 0 3 0ZM3 2C2.73478 2 2.48043 2.10536 2.29289 2.29289C2.10536 2.48043 2 2.73478 2 3V17C2 17.2652 2.10536 17.5196 2.29289 17.7071C2.48043 17.8946 2.73478 18 3 18H9C9.26522 18 9.51957 17.8946 9.70711 17.7071C9.89464 17.5196 10 17.2652 10 17V3C10 2.73478 9.89464 2.48043 9.70711 2.29289C9.51957 2.10536 9.26522 2 9 2H3ZM6 17C5.73478 17 5.48043 16.8946 5.29289 16.7071C5.10536 16.5196 5 16.2652 5 16C5 15.7348 5.10536 15.4804 5.29289 15.2929C5.48043 15.1054 5.73478 15 6 15C6.26522 15 6.51957 15.1054 6.70711 15.2929C6.89464 15.4804 7 15.7348 7 16C7 16.2652 6.89464 16.5196 6.70711 16.7071C6.51957 16.8946 6.26522 17 6 17Z" fill="#4F5D75" />
                                    </svg>
                                </div>
                            </div>
                            <input type="password" class="form-control shadow-none" name="password1" id="password1" value="" placeholder="enter new password">
                        </div>

                        <div class="input-group input-group-nouva1 mb-3 bg-white">
                            <div class="input-group-prepend shadow-none">
                                <div class="input-group-text border-0 text-nouva1">
                                    <svg width="12" height="20" viewBox="0 0 12 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3 0H9C9.79565 0 10.5587 0.316071 11.1213 0.87868C11.6839 1.44129 12 2.20435 12 3V17C12 17.7956 11.6839 18.5587 11.1213 19.1213C10.5587 19.6839 9.79565 20 9 20H3C2.20435 20 1.44129 19.6839 0.87868 19.1213C0.316071 18.5587 0 17.7956 0 17V3C0 2.20435 0.316071 1.44129 0.87868 0.87868C1.44129 0.316071 2.20435 0 3 0ZM3 2C2.73478 2 2.48043 2.10536 2.29289 2.29289C2.10536 2.48043 2 2.73478 2 3V17C2 17.2652 2.10536 17.5196 2.29289 17.7071C2.48043 17.8946 2.73478 18 3 18H9C9.26522 18 9.51957 17.8946 9.70711 17.7071C9.89464 17.5196 10 17.2652 10 17V3C10 2.73478 9.89464 2.48043 9.70711 2.29289C9.51957 2.10536 9.26522 2 9 2H3ZM6 17C5.73478 17 5.48043 16.8946 5.29289 16.7071C5.10536 16.5196 5 16.2652 5 16C5 15.7348 5.10536 15.4804 5.29289 15.2929C5.48043 15.1054 5.73478 15 6 15C6.26522 15 6.51957 15.1054 6.70711 15.2929C6.89464 15.4804 7 15.7348 7 16C7 16.2652 6.89464 16.5196 6.70711 16.7071C6.51957 16.8946 6.26522 17 6 17Z" fill="#4F5D75" />
                                    </svg>
                                </div>
                            </div>
                            <input type="password" class="form-control shadow-none" name="password2" id="password2" value="" placeholder="enter new password again">
                        </div>
                        <button type="submit" class="btn btn-lg btn-nouva1 btn-block rounded-pill">Save Change</button>

                    </form>
                </div>
            </div>

            <div class="mt-5 pt-3 top-border">
                <ul class="listview image-listview mb-2 bg-transparent">
                    <li>
                        <a href="" class="item left">

                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 text-uppercase m-0 font-weight-bolder">FAQ</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a class="item versi">
                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 m-0 font-weight-bolder">Versi App</h3>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?= base_url('auth/logout') ?>" class="item logout">
                            <div class="in align-bottom">
                                <h3 class="title text-nouva1 m-0 font-weight-bolder text-danger">Logout</h3>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="mt-5 mb-5 text-center">
                <div class="sosmed-setting">
                    <a href="https://s.id/DiscordBaliola">
                        <img src="<?= base_url('assets'); ?>/img/icon/discord.svg" alt="discord">
                    </a>
                    <a href="https://t.me/kepengindonesiacommunity">
                        <img src="<?= base_url('assets'); ?>/img/icon/telegram.png" alt="telegram">
                    </a>
                </div>
                <div class="footer-title">
                    Nouvarium © <?= date('Y'); ?><br>
                    Powered by Kepeng.io
                </div>
            </div>
        </div>
    </div>
    <!-- * App Capsule -->