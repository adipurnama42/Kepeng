<body>

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url('assets'); ?>/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Capsule -->
    <div id="appCapsule" class="bg-nouva2">

        <div class="section pt-1">
            <div class="row pl-3 pr-3">
                <div class="col-8">
                    <span class="title-name text-nouva1"><?= $data_user['name']; ?></span>
                    <span class="code-id"><?= $data_user['email']; ?></span>
                </div>
                <div class="col-4">
                    <div class="profile-img">
                        <?php if ($data_user["photo_profile"] != NULL) { ?>
                            <img src="<?= base_url('assets/img/users/' . $data_user['photo_profile']) ?>" alt="image" class="imaged w76" style="height: 100%;" />
                        <?php } else { ?>
                            <img src="<?= base_url('assets'); ?>/img/users/profile.png" alt="image" class="imaged w76" style="height: 100%;">
                        <?php } ?>
                    </div>
                </div>
                <div class="col-12">
                    <div class="balance-kpg text-nouva1">
                        <img src="<?= base_url('assets'); ?>/img/kepeng.png" alt="KPG">
                        <span><?= number_format($data_dompet_user['saldo'], 2, '.', ','); ?> KPG</span><br>
                        <span class="tittle-today">$0 Today</span>
                    </div>
                </div>

                <div class="col-12 wallet-card bg-transparent border-0 shadow-none m-0 p-0">
                    <div class="wallet-footer border-0">
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#receiveActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/receive-icon.svg" alt="Receive">
                                </div>
                                <strong>Receive</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#sendActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/send-icon.svg" alt="Receive">
                                </div>
                                <strong>Send</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#buyActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/buy-icon.svg" alt="Receive">
                                </div>
                                <strong>Buy</strong>
                            </a>
                        </div>
                        <div class="item item-btn-menu-nouva1">
                            <a href="#" data-toggle="modal" data-target="#scanActionSheet">
                                <div class="icon-wrapper-nouva1 rounded-circle bg-white ">
                                    <img src="<?= base_url('assets'); ?>/img/icon/Scan.svg" alt="Receive">
                                </div>
                                <strong>Scan</strong>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions -->
        <div class="section section-nouva1 bg-white mt-4 pb-5 text-center">
            <h2 class="title text-nouva1 mb-2">Token</h2>
            <h1 class="title text-nouva1 mb-2">Coming Soon</h1>
        </div>
        <!-- * Transactions -->

    </div>
    <!-- * App Capsule -->