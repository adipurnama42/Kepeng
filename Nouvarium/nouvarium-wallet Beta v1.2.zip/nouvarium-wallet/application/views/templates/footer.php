<!-- ///////////// Js Files ////////////////////  -->
<!-- Jquery -->
<script src="<?= base_url(''); ?>assets/js/lib/jquery-3.4.1.min.js"></script>
<!-- Bootstrap-->
<script src="<?= base_url(''); ?>assets/js/lib/popper.min.js"></script>
<script src="<?= base_url(''); ?>assets/js/lib/bootstrap.min.js"></script>
<!-- Owl Carousel -->
<script src="<?= base_url(''); ?>assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
<!-- Base Js File -->
<script src="<?= base_url(''); ?>assets/js/base.js"></script>

<script>
    function forceLower(strInput) {
        strInput.value = strInput.value.toLowerCase();
    }​
</script>


</body>

</html>