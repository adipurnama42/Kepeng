<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader no-border bg-nouva1">
        <div class="left">
            <a href="<?= base_url('auth/index'); ?>" class="headerButton goBack text-nouva1">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center text-nouva1">
            <img src="<?= base_url('auth/forgetPassword'); ?>assets/img/logo-1.png" alt="" class="logo-nouva1">
        </div>
        <div class="section mt-5 text-center text-nouva1">
            <h2 class="mb-2">Forgot your password?</h2>
            <p>Reset your password.</p>
        </div>

        <div class="section mt-2 mb-5 p-3">
            <form method="POST" action="<?= base_url('auth/forgetpassword'); ?>" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <label for="name" class="text-nouva1 font-weight-bold">Enter Email</label>
                    <input type="text" name="email" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="email" placeholder="" value="">
                    <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Ask for Verification Code</button>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->