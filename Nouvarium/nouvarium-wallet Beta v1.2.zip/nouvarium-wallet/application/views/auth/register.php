<body class="bg-nouva1">

    <!-- loader -->
    <div id="loader">
        <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="icon" class="loading-icon">
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader no-border bg-nouva1">
        <div class="left">
            <a href="<?= base_url('auth/index'); ?>" class="headerButton goBack text-nouva1">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle"></div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="pl-3 pr-3">

        <div class="section mt-2 text-center text-nouva1">
            <img src="<?= base_url(''); ?>assets/img/logo-1.png" alt="" class="logo-nouva1">
        </div>

        <div class="section mt-2 mb-5 p-3">
            <?php
            if ($this->session->flashdata('messageotp')) {
            ?>
                <div class="alert alert-<?= $this->session->flashdata('color'); ?> mb-2 alert-dismissible fade show" role="alert">
                    <strong>Attention!</strong> <?= $this->session->flashdata('messageotp'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                        </svg>
                    </button>
                </div>
            <?php
            }
            ?>
            <form method="POST" action="<?= base_url('auth/register'); ?>" autocomplete="off" autocapitalize="none">

                <div class="form-group">
                    <label for="name" class="text-nouva1 font-weight-bold">Enter Name</label>
                    <input type="text" name="name" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="name" placeholder="" value="<?= set_value('name'); ?>">
                    <?= form_error('name', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="email" class="text-nouva1 font-weight-bold">Enter E-mail</label>
                    <input type="text" name="email" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="email" placeholder="" value="<?= set_value('email'); ?>">
                    <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="phone" class="text-nouva1 font-weight-bold">Enter Phone Number</label>
                    <input type="text" name="phone" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="phone" placeholder="" value="<?= set_value('phone'); ?>">
                    <?= form_error('phone', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password1" class="text-nouva1 font-weight-bold">Enter Password</label>
                    <input type="password" name="password1" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password1" placeholder="" value="">
                    <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="password2" class="text-nouva1 font-weight-bold">Re-Enter Password</label>
                    <input type="password" name="password2" class="form-control form-control-lg rounded-nouva1 shadow-nouva1" id="password2" placeholder="" value="">
                    <?= form_error('password2', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group basic mt-5">
                    <button type="submit" class="btn btn-nouva1 btn-block btn-lg rounded-pill">Sign
                        Up</button>
                </div>

                <div class="form-group mt-2 text-center text-body">
                    <p>
                        Have an account? <a href="<?= base_url('auth/login'); ?>">Login</a>
                    </p>
                </div>

            </form>
        </div>

    </div>
    <!-- * App Capsule -->