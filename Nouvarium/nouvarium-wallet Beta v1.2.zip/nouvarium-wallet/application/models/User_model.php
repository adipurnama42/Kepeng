<?php


class User_model extends CI_Model
{


    public function getDataHome($id)
    {
        $data_user = $this->db->get_where('users', ['id' => $id])->row_array();
        return $data_user;
    }

    public function getDataUsers($id)
    {
        $data_user = $this->db->get_where('users_dompet', ['id_users' => $id])->row_array();
        return $data_user;
    }


    public function updateProfile1()
    {
        $id = $this->session->userdata("id");
        if ($this->input->post('password1',  TRUE) == !NULL) {
            if ($this->input->post('passowrd1',  TRUE) <> $this->input->post('passowrd2',  TRUE)) {
                $this->session->set_flashdata('flash', 'Password tidak sama!');
                $this->session->set_flashdata('color', 'danger');
            } else {
                $data =
                    [
                        "name" => $this->input->post('name',  TRUE),
                        "email" => $this->input->post('email',  TRUE),
                        "password" => $this->input->post('passowrd1',  TRUE)
                    ];
            }
        } else {
            $data =
                [
                    "name" => $this->input->post('name',  TRUE),
                    "email" => $this->input->post('email',  TRUE)
                ];
        }

        $this->db->where('id', $id);
        $result = $this->db->update('users', $data);

        if ($result != NULL) {
            $this->session->set_flashdata('flash', 'Data Identitas Berhasil Di Update');
            $this->session->set_flashdata('color', 'success');
        } else {
            $this->session->set_flashdata('flash', 'Data Identitas Gagal Di Update');
            $this->session->set_flashdata('color', 'danger');
        }
    }

    public function updateProfile2()
    {
        $id = $this->session->userdata("id");
        $data =
            [
                "email"        => $this->input->post('email',  TRUE),
                "password"      => password_hash($this->input->post('password', true), PASSWORD_DEFAULT),
            ];

        $this->db->where('id', $id);
        $result = $this->db->update('users', $data);

        if ($result != NULL) {
            $this->session->set_flashdata('flash', 'Data Akun Berhasil Di Update');
            $this->session->set_flashdata('color', 'success');
        } else {
            $this->session->set_flashdata('flash', 'Data Akun Gagal Di Update');
            $this->session->set_flashdata('color', 'danger');
        }
    }
    public function allRiwayatTransaksi()
    {
        $id = $this->session->userdata('id');

        $this->db->select('
            users_transaksi.id_transaksi, users_transaksi.sender_id
            , (SELECT name FROM users WHERE id = users_transaksi.sender_id) AS sender_name
            , users_transaksi.recipient_id
            , (SELECT name FROM users WHERE id = users_transaksi.recipient_id) AS recipient_name,
            users_transaksi.*
        ');
        $this->db->from('users_transaksi');
        $this->db->order_by('tanggal', 'DESC');
        $result = $this->db->get()->result_array();

        return $result;
    }

    public function riwayatTransaksi($date, $limit)
    {
        $id = $this->session->userdata('id');

        $this->db->select('
            users_transaksi.id_transaksi, users_transaksi.sender_id
            , (SELECT name FROM users WHERE id = users_transaksi.sender_id) AS sender_name
            , users_transaksi.recipient_id
            , (SELECT name FROM users WHERE id = users_transaksi.recipient_id) AS recipient_name,
            users_transaksi.*
        ');
        $this->db->from('users_transaksi');
        $where =
            '( users_transaksi.sender_id = ' . $id .
            ' OR users_transaksi.recipient_id = ' . $id .
            ') AND tanggal LIKE ' . '"%' . $date . '%"';
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->order_by('tanggal', 'DESC');
        $result = $this->db->get()->result_array();

        return $result;
    }


    public function riwayatTransaksiKirim($date, $limit)
    {
        $id = $this->session->userdata('id');

        $this->db->select('
            users_transaksi.id_transaksi, users_transaksi.sender_id
            , (SELECT name FROM users WHERE id = users_transaksi.sender_id) AS sender_name
            , users_transaksi.recipient_id
            , (SELECT name FROM users WHERE id = users_transaksi.recipient_id) AS recipient_name,
            users_transaksi.*
        ');
        $this->db->from('users_transaksi');
        $where = '( users_transaksi.sender_id = ' . $id .  ') AND tanggal LIKE ' . '"%' . $date . '%"';
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->order_by('tanggal', 'DESC');
        $result = $this->db->get()->result_array();

        return $result;
    }

    public function riwayatTransaksiTerima($date, $limit)
    {
        $id = $this->session->userdata('id');

        $this->db->select('
            users_transaksi.id_transaksi, users_transaksi.sender_id
            , (SELECT name FROM users WHERE id = users_transaksi.sender_id) AS sender_name
            , users_transaksi.recipient_id
            , (SELECT name FROM users WHERE id = users_transaksi.recipient_id) AS recipient_name,
            users_transaksi.*
        ');
        $this->db->from('users_transaksi');
        $where = '( users_transaksi.recipient_id = ' . $id .  ') AND tanggal LIKE ' . '"%' . $date . '%"';
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->order_by('tanggal', 'DESC');
        $result = $this->db->get()->result_array();

        return $result;
    }
}
