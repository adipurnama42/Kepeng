<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Homepage extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();

        $this->load->model('User_model', 'User');
        $this->load->model('Transaction_model');
        $this->load->model('Auth_model');

        if (!$this->session->userdata('id')) {
            redirect('auth');
        } else {
            $data_user = $this->User->getDataHome($this->session->userdata('id'));
            if ($data_user == NULL) {
                redirect('homepage');
            }
        }
    }

    public function index($id = false)
    {
        $today = date("Y-m-d");
        $yesterday = date("Y-m-d", (strtotime('-1 day', strtotime($today))));

        $id = $this->session->userdata("id");
        $data["data_user"] = $this->User->getDataHome($id);
        $data["data_dompet_user"] = $this->User->getDataUsers($id);
        $data["all_transaksi"] = $this->User->allRiwayatTransaksi();
        $data["today"] = $this->User->riwayatTransaksi($today, 4);
        $data["yesterday"] = $this->User->riwayatTransaksi($yesterday, 2);
        $data["today_sender"] = $this->User->riwayatTransaksiKirim($today, 4);
        $data["yesterday_sender"] = $this->User->riwayatTransaksiKirim($yesterday, 2);
        $data["today_receive"] = $this->User->riwayatTransaksiTerima($today, 4);
        $data["yesterday_receive"] = $this->User->riwayatTransaksiTerima($yesterday, 2);
        $user = $this->User->getDataHome($id);

        // $data["data_lomba"] = $this->User->getAllLomba();
        $data['title'] = "Beranda";

        if ($user['is_active'] <= 0) {
            $this->resendotp();
            redirect('Auth/otp');
        } else {
            $this->load->view('templates/headerauth', $data);
            $this->load->view('user/index', $data);
            $this->load->view('templates/modal', $data);
            $this->load->view('templates/navbottom');
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/footer');
        }
    }

    public function resendotp()
    {
        $id = $this->session->userdata('id');
        $this->Auth_model->resendOtp($id);
        redirect('auth/otp');
    }

    public function sendkepeng()
    {
        $this->Transaction_model->sendKpg();
        redirect('homepage/sendkpg_notif');
    }

    public function sendkpg_notif()
    {
        $data['title'] = "Notification";
        $this->load->view('templates/headerauth', $data);
        $this->load->view('templates/notif_transaksi', $data);
        $this->load->view('templates/footer');
    }
}
